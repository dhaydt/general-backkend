<?php $__env->startSection('title', 'Service Edit'); ?>

<?php $__env->startPush('css_or_js'); ?>
<link href="<?php echo e(asset('public/assets/back-end/css/tags-input.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('public/assets/select2/css/select2.min.css')); ?>" rel="stylesheet">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin-views.service.partials._headerAddNew', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Page Heading -->
<div class="content container-fluid mt--8">
    <!-- Content Row -->
    <div class="row">
        <div class="col-md-12">
            <form class="product-form" action="<?php echo e(route('admin.updateService',$product->id)); ?>" method="post"
                style="text-align: <?php echo e(Session::get('direction') === " rtl" ? 'right' : 'left'); ?>;"
                enctype="multipart/form-data" id="product_form">
                <?php echo csrf_field(); ?>

                <div class="card">
                    <div class="card-header">
                        
                        <?php ($default_lang = 'en'); ?>
                        <?php ($lang = 'en'); ?>

                        
                        <ul class="nav nav-tabs mb-4">
                            
                            <li class="nav-item">
                                <a class="nav-link lang_link <?php echo e($lang == $default_lang? 'active':''); ?>" href="#"
                                    id="<?php echo e($lang); ?>-link">Edit <?php echo e($product->name); ?></a>
                            </li>
                            
                        </ul>
                    </div>

                    <div class="card-body">

                        <div class="<?php echo e($lang != 'en'? 'd-none':''); ?> lang_form" id="<?php echo e($lang); ?>-form">
                            <div class="form-group">
                                <label class="input-label" for="<?php echo e($lang); ?>_ame"><?php echo e(('Name')); ?>

                                    (<?php echo e(strtoupper($lang)); ?>)</label>
                                <input type="text" <?php echo e($lang=='en' ? 'required' :''); ?> name="name[]" id="<?php echo e($lang); ?>_name"
                                    value="<?php echo e($translate[$lang]['name']??$product['name']); ?>" class="form-control"
                                    placeholder="<?php echo e(('New Product')); ?>" required>
                            </div>
                            <input type="hidden" name="lang[]" value="<?php echo e($lang); ?>">
                            <div class="form-group pt-4">
                                <label class="input-label"><?php echo e(('Description')); ?>

                                    (<?php echo e(strtoupper($lang)); ?>)</label>
                                <textarea name="description[]" style="display:none" class="textarea"
                                    required><?php echo $product['details']; ?></textarea>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card mt-2 rest-part">
                    <div class="card-header">
                        <h4><?php echo e(('General Info')); ?></h4>
                    </div>
                    <div class="card-body">
                        <div class="card mt-2 rest-part">
                            <div class="card-header">
                                <h4>Service price & image</h4>
                            </div>
                            <div class="card-body">
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label class="control-label"><?php echo e(('Unit price')); ?></label>
                                            <input type="number" min="0" step="0.01" placeholder="<?php echo e(('Unit price')); ?>"
                                                name="unit_price" class="form-control" value=<?php echo e(($product->price)); ?>

                                            required>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label><?php echo e(('Upload product images')); ?></label><small style="color: red">*
                                                    (
                                                    <?php echo e(('ratio')); ?> 1:1 )</small>
                                            </div>
                                            <div class="p-2 border border-dashed" style="max-width:430px;">
                                                <div class="row" id="coba">
                                                    
                                                    <?php $__currentLoopData = json_decode($product->images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="col-6">
                                                        <div class="card">
                                                            <div class="card-body">
                                                                <img style="width: 100%" height="auto"
                                                                    onerror="this.src='<?php echo e(asset('assets/img/image-place-holder.png')); ?>'"
                                                                    src="<?php echo e(asset("storage/service/".$photo)); ?>"
                                                                    alt="Product image">
                                                                

                                                            </div>
                                                        </div>
                                                    </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                                <br>
                            </div>
                        </div>

                        <div class="card card-footer">
                            <div class="row">
                                <div class="col-md-12" style="padding-top: 20px">
                                    <?php if($product->request_status == 2): ?>
                                    <button type="button" onclick="check()" class="btn btn-primary"><?php echo e(('Update &
                                        Publish')); ?></button>
                                    <?php else: ?>
                                    <button type="button" onclick="check()"
                                        class="btn btn-primary"><?php echo e(('Update')); ?></button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>
<script src="<?php echo e(asset('assets/back-end')); ?>/js/tags-input.min.js"></script>
<script src="<?php echo e(asset('assets/back-end/js/spartan-multi-image-picker.js')); ?>"></script>
<script>
    var imageCount = 1;
        var thumbnail = '<?php echo e(\App\CPU\ProductManager::product_image_path('thumbnail').'/'.$product->thumbnail??asset('public/assets/back-end/img/400x400/img2.jpg')); ?>';
        $(function () {
            if (imageCount > 0) {
                $("#coba").spartanMultiImagePicker({
                    fieldName: 'images[]',
                    maxCount: imageCount,
                    rowHeight: 'auto',
                    groupClassName: 'col-6',
                    maxFileSize: '',
                    placeholderImage: {
                        image: '<?php echo e(asset('assets/back-end/img/400x400/img2.jpg')); ?>',
                        width: '100%',
                    },
                    dropFileLabel: "Drop Here",
                    onAddRow: function (index, file) {

                    },
                    onRenderedPreview: function (index) {

                    },
                    onRemoveRow: function (index) {

                    },
                    onExtensionErr: function (index, file) {
                        toastr.error('<?php echo e(('Please only input png or jpg type file')); ?>', {
                            CloseButton: true,
                            ProgressBar: true
                        });
                    },
                    onSizeErr: function (index, file) {
                        toastr.error('<?php echo e(('File size too big')); ?>', {
                            CloseButton: true,
                            ProgressBar: true
                        });
                    }
                });
            }

            $("#thumbnail").spartanMultiImagePicker({
                fieldName: 'image',
                maxCount: 1,
                rowHeight: 'auto',
                groupClassName: 'col-6',
                maxFileSize: '',
                placeholderImage: {
                    image: '<?php echo e(asset('assets/back-end/img/400x400/img2.jpg')); ?>',
                    width: '100%',
                },
                dropFileLabel: "Drop Here",
                onAddRow: function (index, file) {

                },
                onRenderedPreview: function (index) {

                },
                onRemoveRow: function (index) {

                },
                onExtensionErr: function (index, file) {
                    toastr.error('<?php echo e(('Please only input png or jpg type file')); ?>', {
                        CloseButton: true,
                        ProgressBar: true
                    });
                },
                onSizeErr: function (index, file) {
                    toastr.error('<?php echo e(('File size too big')); ?>', {
                        CloseButton: true,
                        ProgressBar: true
                    });
                }
            });

            $("#meta_img").spartanMultiImagePicker({
                fieldName: 'meta_image',
                maxCount: 1,
                rowHeight: 'auto',
                groupClassName: 'col-6',
                maxFileSize: '',
                placeholderImage: {
                    image: '<?php echo e(asset('assets/back-end/img/400x400/img2.jpg')); ?>',
                    width: '100%',
                },
                dropFileLabel: "Drop Here",
                onAddRow: function (index, file) {

                },
                onRenderedPreview: function (index) {

                },
                onRemoveRow: function (index) {

                },
                onExtensionErr: function (index, file) {
                    toastr.error('<?php echo e(('Please only input png or jpg type file')); ?>', {
                        CloseButton: true,
                        ProgressBar: true
                    });
                },
                onSizeErr: function (index, file) {
                    toastr.error('<?php echo e(('File size too big')); ?>', {
                        CloseButton: true,
                        ProgressBar: true
                    });
                }
            });
        });

        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#viewer').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#customFileUpload").change(function () {
            readURL(this);
        });

        $(".js-example-theme-single").select2({
            theme: "classic"
        });

        $(".js-example-responsive").select2({
            width: 'resolve'
        });
</script>

<script>
    function check() {
            for (instance in CKEDITOR.instances) {
                CKEDITOR.instances[instance].updateElement();
            }
            var formData = new FormData(document.getElementById('product_form'));
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.post({
                url: '<?php echo e(route('admin.updateService',$product->id)); ?>',
                data: formData,
                contentType: false,
                processData: false,
                success: function (data) {
                    if (data.errors) {
                        for (var i = 0; i < data.errors.length; i++) {
                            toastr.error(data.errors[i].message, {
                                CloseButton: true,
                                ProgressBar: true
                            });
                        }
                    } else {
                        toastr.success('Service berhasil di update!', {
                            CloseButton: true,
                            ProgressBar: true
                        });
                        $('#product_form').submit();
                    }
                }
            });
        };
</script>

<script>
    update_qty();

        function update_qty() {
            var total_qty = 0;
            var qty_elements = $('input[name^="qty_"]');
            for (var i = 0; i < qty_elements.length; i++) {
                total_qty += parseInt(qty_elements.eq(i).val());
            }
            if (qty_elements.length > 0) {

                $('input[name="current_stock"]').attr("readonly", true);
                $('input[name="current_stock"]').val(total_qty);
            } else {
                $('input[name="current_stock"]').attr("readonly", false);
            }
        }

        $('input[name^="qty_"]').on('keyup', function () {
            var total_qty = 0;
            var qty_elements = $('input[name^="qty_"]');
            for (var i = 0; i < qty_elements.length; i++) {
                total_qty += parseInt(qty_elements.eq(i).val());
            }
            $('input[name="current_stock"]').val(total_qty);
        });
</script>

<script>
    $(".lang_link").click(function (e) {
            e.preventDefault();
            $(".lang_link").removeClass('active');
            $(".lang_form").addClass('d-none');
            $(this).addClass('active');

            let form_id = this.id;
            let lang = form_id.split("-")[0];
            console.log(lang);
            $("#" + lang + "-form").removeClass('d-none');
            if (lang == 'EN') {
                $(".rest-part").removeClass('d-none');
            } else {
                $(".rest-part").addClass('d-none');
            }
        })
</script>

<script src="<?php echo e(asset('/')); ?>vendor/unisharp/laravel-ckeditor/ckeditor.js"></script>
<script src="<?php echo e(asset('/')); ?>vendor/unisharp/laravel-ckeditor/adapters/jquery.js"></script>

<script>
    $('.textarea').ckeditor({
            contentsLangDirection : '<?php echo e(Session::get('direction')); ?>',
        });
</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mh/code/project.co/Tigatech/Ongoing/backend_lara/resources/views/admin-views/service/editService.blade.php ENDPATH**/ ?>