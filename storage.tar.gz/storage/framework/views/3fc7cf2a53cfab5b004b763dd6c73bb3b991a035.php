<footer class="footer">
    <?php echo $__env->make('layouts.footers.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</footer><?php /**PATH /home/mh/code/project.co/Tigatech/Ongoing/backend_lara/resources/views/layouts/footers/auth.blade.php ENDPATH**/ ?>