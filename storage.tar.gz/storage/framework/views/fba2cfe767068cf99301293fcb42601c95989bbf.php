<?php $__env->startSection('title', ('Payment')); ?>
<?php $__env->startPush('css_or_js'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopPush(); ?>
<style>
    .btn.btn-primary {
        text-transform: capitalize;
    }
</style>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin-views.payment.partials._headerBussines', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="content container-fluid mt--8">

    <div class="row" style="margin-top: 20px" id="banner-table">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="flex-between row justify-content-between align-items-center flex-grow-1 mx-1">
                        <div class="flex-between d-flex">
                            <div>
                                <h5>Payment Service</h5>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body" style="padding: 0">
                    <div class="table-responsive">
                        <table id="columnSearchDatatable" style="text-align: <?php echo e(Session::get('direction') === " rtl"
                            ? 'right' : 'left'); ?>;"
                            class="table table-borderless table-thead-bordered table-nowrap table-align-middle card-table">
                            <thead class="thead-light">
                                <tr>
                                    <th><?php echo e(('sl')); ?></th>
                                    <th><?php echo e(('payment')); ?></th>
                                    <th><?php echo e(('type')); ?></th>
                                    <th><?php echo e(('status')); ?></th>
                                    
                                </tr>
                            </thead>
                            <?php $__currentLoopData = $payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$pay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tbody>

                                <tr>
                                    <th scope="row"><?php echo e($pay->id); ?></th>
                                    <td><?php echo e($pay->name); ?></td>
                                    <td><?php echo e($pay->type); ?></td>
                                    <td>
                                        <div class="form-check form-switch switch switch-status">
                                            <input class="form-check-input status" type="checkbox" role="switch"
                                                id="<?php echo e($pay->id); ?>" <?php if ($pay->status == 1) echo "checked"
                                            ?>>
                                        </div>
                                    </td>

                                    
                                </tr>

                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
                <div class="card-footer">
                    
                </div>
                <?php if(count($payment)==0): ?>
                <div class="text-center p-4">
                    <img class="mb-3" src="<?php echo e(asset('assets/back-end')); ?>/svg/illustrations/sorry.svg"
                        alt="Image Description" style="width: 7rem;">
                    <p class="mb-0"><?php echo e(('No_data_to_show')); ?></p>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('assets/back-end')); ?>/js/select2.min.js"></script>
<script>

        $(document).on('change', '.status', function () {
            var id = $(this).attr("id");
            if ($(this).prop("checked") == true) {
                var status = 1;
            } else if ($(this).prop("checked") == false) {
                var status = 0;
            }

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url: "<?php echo e(route('admin.payment.status')); ?>",
                method: 'POST',
                data: {
                    id: id,
                    status: status
                },
                success: function (data) {
                    if (data == 1) {
                        toastr.success('Payment status activated successfully');
                    } else {
                        toastr.success('Payment status deactivated successfully');
                    }
                }
            });
        });

        $(document).on('click', '.delete', function () {
            var id = $(this).attr("id");
            Swal.fire({
                title: "Are you sure delete this banner",
                text: "You will not be able to revert this",
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it'
            }).then((result) => {
                if (result.value) {
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.ajax({
                        url: "<?php echo e(route('admin.banner.delete')); ?>",
                        method: 'POST',
                        data: {id: id},
                        success: function () {
                            toastr.success('<?php echo e(('Banner_deleted_successfully')); ?>');
                            location.reload();
                        }
                    });
                }
            })
        });

        $(document).on('click', '.edit', function () {
            var id = $(this).attr("id");
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url: "<?php echo e(route('admin.banner.edit')); ?>",
                method: 'POST',
                data: {id: id},
                success: function (data) {
                    $('.banner_form').attr('action', "<?php echo e(route('admin.banner.update')); ?>");
                    // console.log(data);
                    if (data.banner_type == 'Main Banner') {

                        $('#main-banner').show();
                        $('#banner-table').hide();
                        $('#add').html("<?php echo e(('update')); ?>");
                        // $('#add').hide();
                        // $('#update').show();
                        // $('#id').val(data.id);
                        $('#url').val(data.url);
                        $('#url').siblings('#id').val(data.id);
                        $('#mbImageviewer').attr('src', "<?php echo e(asset('storage/banner')); ?>" + "/" + data.photo);
                        $('#cate-table').hide();

                    } else if (data.banner_type == 'Footer Banner') {

                        $('#secondary-banner').show();
                        $('#banner-table').hide();
                        // $('#addfooter').hide();
                        $('#addfooter').html("<?php echo e(('update')); ?>");
                        // $('#footerupdate').show();
                        // $('#id').val(data.id);
                        $('#footerurl').val(data.url);
                        $('#footerurl').siblings('#id').val(data.id);
                        $('#fbImageviewer').attr('src', "<?php echo e(asset('storage/banner')); ?>" + "/" + data.photo);
                        $('#cate-table').hide();


                    } else if (data.banner_type == 'Header Banner') {

                        $('#header-banner').show();
                        $('#banner-table').hide();
                        // $('#addfooter').hide();
                        $('#addheader').html("<?php echo e(('update')); ?>");
                        // $('#footerupdate').show();
                        // $('#id').val(data.id);
                        $('#headerurl').val(data.url);
                        $('#headerurl').siblings('#id').val(data.id);
                        $('#headerurl2').val(data.url2);
                        $('#headerurl2').siblings('#id').val(data.id);
                        $('#fbImageviewer').attr('src', "<?php echo e(asset('storage/banner')); ?>" + "/" + data.photo);
                        $('#cate-table').hide();


                    } else if (data.banner_type == 'Floating Banner') {

                        $('#floating-banner').show();
                        $('#banner-table').hide();
                        // $('#addfooter').hide();
                        $('#addfloating').html("<?php echo e(('update')); ?>");
                        // $('#footerupdate').show();
                        // $('#id').val(data.id);
                        $('#floatingurl').val(data.url);
                        $('#floatingurl').siblings('#id').val(data.id);
                        $('#fbImageviewer').attr('src', "<?php echo e(asset('storage/banner')); ?>" + "/" + data.photo);
                        $('#cate-table').hide();


                    } else {
                        $('#popup-banner').show();
                        $('#banner-table').hide();
                        $('#addpopup').html("<?php echo e(('update')); ?>");
                        // $('#addpopup').hide();
                        // $('#popupupdate').show();
                        // $('#id').val(data.id);
                        $('#popupurl').val(data.url);
                        $('#popupurl').siblings('#id').val(data.id);
                        $('#pbImageviewer').attr('src', "<?php echo e(asset('storage/banner')); ?>" + "/" + data.photo);
                        $('#cate-table').hide();
                    }


                }
            });
        });
        $('#update').on('click', function () {
            $('#update').attr("disabled", true);
            var id = $('#id').val();
            var name = $('#url').val();
            var type = $('#type').val();

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $.ajax({
                url: "<?php echo e(route('admin.banner.update')); ?>",
                method: 'POST',
                data: {
                    id: id,
                    url: name,
                    banner_type: type,

                },
                success: function (data) {
                    console.log(data);
                    $('#url').val('');
                    $.ajax({
                        type: 'get',
                        url: '<?php echo e(route('image-remove',[0,'main_banner_image_modal'])); ?>',
                        dataType: 'json',
                        success: function (data) {
                            if (data.success === 1) {
                                $("#img-suc").hide();
                                $("#img-err").hide();
                                $("#crop").hide();
                                $("#show-images").html(data.photo);
                                $("#image-count").text(data.count);
                            } else if (data.success === 0) {
                                $("#img-suc").hide();
                                $("#img-err").show();
                            }
                        },
                    });
                    toastr.success('<?php echo e(('Main_Banner_updated_Successfully')); ?>.');


                    location.reload();
                }
            });
            $('#save').hide();

        });
        $('#footerupdate').on('click', function () {
            $('#footerupdate').attr("disabled", true);
            var id = $('#id').val();
            var name = $('#footerurl').val();
            var type = $('#footertype').val();
            console.log(type)

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $.ajax({
                url: "<?php echo e(route('admin.banner.update')); ?>",
                method: 'POST',
                data: {
                    id: id,
                    url: name,
                    banner_type: type,

                },
                success: function (data) {

                    $('#url').val('');
                    $.ajax({
                        type: 'get',
                        url: '<?php echo e(route('image-remove',[0,'secondary_banner_image_modal'])); ?>',
                        dataType: 'json',
                        success: function (data) {
                            if (data.success === 1) {
                                $("#img-suc").hide();
                                $("#img-err").hide();
                                $("#crop").hide();
                                $("#show-images").html(data.photo);
                                $("#image-count").text(data.count);
                            } else if (data.success === 0) {
                                $("#img-suc").hide();
                                $("#img-err").show();
                            }
                        },
                    });
                    toastr.success('<?php echo e(('Secondary_Banner_updated_Successfully')); ?>.');


                    location.reload();
                }
            });
            $('#save').hide();

        });
        $('#popupupdate').on('click', function () {
            $('#popupupdate').attr("disabled", true);
            var id = $('#id').val();
            var name = $('#popupurl').val();
            var type = $('#popuptype').val();


            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $.ajax({
                url: "<?php echo e(route('admin.banner.update')); ?>",
                method: 'POST',
                data: {
                    id: id,
                    url: name,
                    banner_type: type,

                },
                success: function (data) {

                    $('#url').val('');
                    $.ajax({
                        type: 'get',
                        url: '<?php echo e(route('image-remove',[0,'popup_banner_image_modal'])); ?>',
                        dataType: 'json',
                        success: function (data) {
                            if (data.success === 1) {
                                $("#img-suc").hide();
                                $("#img-err").hide();
                                $("#crop").hide();
                                $("#show-images").html(data.photo);
                                $("#image-count").text(data.count);
                            } else if (data.success === 0) {
                                $("#img-suc").hide();
                                $("#img-err").show();
                            }
                        },
                    });
                    toastr.success('<?php echo e(('Popup_Banner_updated_Successfully')); ?>.');


                    location.reload();
                }
            });
            $('#save').hide();

        });

</script>
<!-- Page level plugins -->
<script src="<?php echo e(asset('assets/back-end')); ?>/vendor/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo e(asset('assets/back-end')); ?>/vendor/datatables/dataTables.bootstrap4.min.js"></script>
<script>
    $(document).ready(function () {
            $('#dataTable').DataTable();
        });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mh/code/project.co/Tigatech/Ongoing/backend_lara/resources/views/admin-views/payment/paymentList.blade.php ENDPATH**/ ?>