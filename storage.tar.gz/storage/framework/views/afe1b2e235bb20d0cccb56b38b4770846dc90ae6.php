<style>
    .breadcumb-item{
        text-transform: capitalize;
    }
</style>
<div class="header bg-primary pb-8 pt-3 pt-md-6">
    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-6 col-7">
                    
                    <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-2">
                        <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><i class="fas fa-home"></i></a></li>
                            <li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(route('admin.listService')); ?>">Service</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Add Service</li>
                        </ol>
                    </nav>
                </div>
                <div class="col-lg-6 col-5 text-right">
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/mh/code/project.co/Tigatech/Ongoing/backend_lara/resources/views/admin-views/service/partials/_headerAddNew.blade.php ENDPATH**/ ?>